var express = require('express');

//var router = express.Router()

//base url for controller
//const router = require('./user/routes/user_routes');

module.exports = (app) => {

    const router = require('./user/user_routes');

    app.use('/user', router)};