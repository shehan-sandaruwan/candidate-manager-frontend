const express = require('express');
const router = express.Router();
const bodyParser = require('body-parser');
const axios = require('axios');
var http = require("http");

router.use(bodyParser.urlencoded({ extended: true }));
router.use(bodyParser.json());

const {serverUrl,serverPort} = require('../constants');

//GET method
router.get('/', (req, res) => {
    var queryParams = {
        host: serverUrl,
        port: serverPort,
        path: '/users',
        method: 'GET'
    };
    var request = http.request(queryParams, function(response) {
        //var parsed = JSON.parse(response);
        response.setEncoding('utf8');
        var str = '';
        response.on('data', function (chunk) {
            str += chunk;
            
        });
        response.on('end',function(){
            var parsed = JSON.parse(str);
            
            res.send(parsed);
        });
        

    });
    request.end();
    
});

//POST method
router.post('/', (req, res) => {

    var reqData = JSON.stringify(req.body);
    var queryParams = {
        host: serverUrl,
        port: serverPort,
        path: '/users',
        method: 'POST',
        headers: {'Content-type': 'application/json',
        "Content-Length": Buffer.byteLength(reqData)
        }
    };
    var request = http.request(queryParams, function(response) {
        response.setEncoding('utf8');
        var str = '';
        response.on('data', function (chunk) {
            str += chunk;
        });
        response.on('end',function(){
            var parsed = JSON.parse(str);
            res.send(parsed);
        });
        

    });
    request.write(reqData);
    request.end();

});




module.exports = router;